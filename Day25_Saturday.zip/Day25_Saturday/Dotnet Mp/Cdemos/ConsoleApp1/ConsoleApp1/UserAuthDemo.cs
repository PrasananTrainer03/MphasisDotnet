﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Collections.Specialized;
using System.Threading.Tasks;

namespace ConsoleApp1
{

    class UserAuthDemo
    {
        //public void Demo(string user,string password)
        //{
        //   Dictionary nvc = new NameValueCollection();
            
        //    nvc.Add("Arka", "Mitra");
        //    nvc.Add("Rakesh", "Mishra");
        //    nvc.Add("Abhishek", "Anand");
        //    nvc.Add("Sakshi", "Mishra");
        //    nvc.Add("Naveen", "Koduru");

        //    string result = string.Empty;
        //    nvc.getor
        //}
    }
}
