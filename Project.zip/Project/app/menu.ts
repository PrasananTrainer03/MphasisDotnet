export class Menu {
    
    public foodId : number;
    public foodName : string;
    public foodPrice : number;
    public foodDetails : string;
    public foodStatus : string;
    public foodRating : string;
    constructor(  ){}
}