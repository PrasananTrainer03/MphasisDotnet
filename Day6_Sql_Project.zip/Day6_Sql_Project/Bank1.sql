Create Database BankProject
Go

use BankProject 
GO
