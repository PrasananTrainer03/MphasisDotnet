export class Student {​​​​​
    constructor(
    public sno : number,
    public firstName : string,
    public lastName : string,
    public city : string,
    public cgpa : number
    ) {​​​​​
    }​​​​​
    }​​​​​
