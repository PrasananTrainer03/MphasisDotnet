select * from Employ;

delete from Employ where Ecode=10;

delete from Employ where ecode=9;

