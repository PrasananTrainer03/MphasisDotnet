import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-vendor-info',
  templateUrl: './vendor-info.component.html',
  styleUrls: ['./vendor-info.component.css']
})
export class VendorInfoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
