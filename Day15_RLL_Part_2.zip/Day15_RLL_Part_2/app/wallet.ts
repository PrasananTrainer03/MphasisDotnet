export class Wallet {

    public walletId : number;
    public customerId : number;
    public wallettype : string;
    public amount : number;
    constructor() {

    }
}
