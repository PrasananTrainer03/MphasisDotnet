import { Menu } from './menu';

describe('Menu', () => {
  it('should create an instance', () => {
    expect(new Menu()).toBeTruthy();
  });
});
