export class Restaurant {

    public rid : number;
    public rname : string;
    public branch : string;
    public contactNo : string;
    public city : string;
    public email : string;
    constructor() {

    }
}
