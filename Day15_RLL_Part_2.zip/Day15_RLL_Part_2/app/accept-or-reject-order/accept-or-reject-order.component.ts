import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-accept-or-reject-order',
  templateUrl: './accept-or-reject-order.component.html',
  styleUrls: ['./accept-or-reject-order.component.css']
})
export class AcceptOrRejectOrderComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
