-- Display last occurrence of given char in a string 
Example : Name 'keerthi' 'e' exists 2 times print last occurrence 

-- Take Name as 'Abhishek Anand' and split into FirstName and LastName 

-- Display all names of Emp table in sentence case (means first char 
upper case remaining lower case) 

-- In Word 'misissipi' count no.of i's

-- Add 7 years 5 months and 10 days to the today's date 

-- Display last day of the next month

-- Display first day of the previous month

-- Display all fridays of current month 

-- Write a query, whose name starts and ends with same char (example : karthik, naveen, suhaas) 

-- Write a Query, who have 2 part names in their name 

-- Write a Queuery, whose First 2 part names starts with same char (example Kiran Kumar) 

