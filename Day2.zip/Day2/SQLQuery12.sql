-- Cross Join : Generates cartician product of 2 tables 

Example : Table A contains n records and Table B contains m records then the output
will generate n*m records 

select * from Agent Cross Join AgentPolicy

select * from Policy CROSS JOIN AgentPolicy

-- self join : If a table joins with itself known as Self Join 

