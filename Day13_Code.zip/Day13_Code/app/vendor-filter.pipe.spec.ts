import { VendorFilterPipe } from './vendor-filter.pipe';

describe('VendorFilterPipe', () => {
  it('create an instance', () => {
    const pipe = new VendorFilterPipe();
    expect(pipe).toBeTruthy();
  });
});
