export class Customer {
    
    public cusId : number;
    public cusName : string; 
    public cusPassword : string;
    public cusEmail : string;
    public cusMobile : string; 
    public cusDob : string;
    public cusAddress : string; 
    constructor()
{ }
}
